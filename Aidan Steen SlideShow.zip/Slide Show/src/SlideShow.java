//Aidan Steen

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Color;

public class SlideShow extends JFrame {

	//Declare Variables
	private JPanel slidePane;
	private JPanel textPane;
	private JPanel buttonPane;
	private CardLayout card;
	private CardLayout cardText;
	private JButton btnPrev;
	private JButton btnNext;
	private JLabel lblSlide;
	private JLabel lblTextArea;

	/**
	 * Create the application.
	 */
	public SlideShow() throws HeadlessException {
		initComponent();
		
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initComponent() {
		//Initialize variables to empty objects
		card = new CardLayout();
		cardText = new CardLayout();
		slidePane = new JPanel();
		textPane = new JPanel();
		textPane.setBackground(Color.BLUE);
		textPane.setBounds(5, 470, 790, 50);
		textPane.setVisible(true);
		buttonPane = new JPanel();
		btnPrev = new JButton();
		btnNext = new JButton();
		
		lblSlide = new JLabel();
		lblTextArea = new JLabel();

		//Setup frame attributes
		setSize(800, 600);
		setLocationRelativeTo(null);
		setTitle("Top 5 Destinations SlideShow");
		getContentPane().setLayout(new BorderLayout(10, 50));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		//Setting the layouts for the panels
		
		slidePane.setLayout(card);
		textPane.setLayout(cardText);
		
				
		//logic to add each of the slides and text
		for (int i = 1; i <= 5; i++) {
			lblSlide = new JLabel();
			lblTextArea = new JLabel();
			lblSlide.setText(getResizeIcon(i));
			lblTextArea.setText(getTextDescription(i));
			slidePane.add(lblSlide, "card" + i);
			textPane.add(lblTextArea, "cardText" + i);
		}

		getContentPane().add(slidePane, BorderLayout.CENTER);
		getContentPane().add(textPane, BorderLayout.SOUTH);

		buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));

		btnPrev.setText("Previous");
		btnPrev.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				goPrevious();
			}
		});
		buttonPane.add(btnPrev);

		btnNext.setText("Next");
		btnNext.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				goNext();
			}
		});
		buttonPane.add(btnNext);

		getContentPane().add(buttonPane, BorderLayout.SOUTH);

		
	}

	/**
	 * Previous Button Functionality
	 */
	private void goPrevious() {
		card.previous(slidePane);
		cardText.previous(textPane);
	}
	
	/**
	 * Next Button Functionality
	 */
	private void goNext() {
		card.next(slidePane);
		cardText.next(textPane);
		
	}

	/**
	 * Method to get the images
	 */
	private String getResizeIcon(int i) {
		String image = ""; 
		if (i==1){
			//Changed image to Greece, Euphoria.jpg
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/Greece, Euphoria.jpg") + "'</body></html>";
		} else if (i==2){
			//Changed image to New Mexico, Ojo Caliente.jpg
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/New Mexico, Ojo Caliente.jpg") + "'</body></html>";
		} else if (i==3){
			//Changed image to New Zealand, Aro Ha.jpg
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/New Zealand, Aro Ha.jpg") + "'</body></html>";
		} else if (i==4){
			//Changed image to Turkey, Sianji.jpg
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/Turkey, Sianji.jpg") + "'</body></html>";
		} else if (i==5){
			//Changed image to Thailand, Barai.jpg
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/Thailand, Barai.jpg") + "'</body></html>";
		}
		return image;
	}
	
	/**
	 * Method to get the text values
	 */
	private String getTextDescription(int i) {
		String text = ""; 
		if (i==1){
			//Changed texts to match new images
			text = "<html><body><font size='5'>#1 Greece, Euphoria Retreat</font>\tGive your body the opportunity to rebalance itself with a well-being detox "
					+ "retreat in the peace and quiet of Euphoria Retreat<br></body></html>";
		} else if (i==2){
			//Changed texts to match new images
			text = "<html><body><font size='5'>#2 New Mexico, Ojo Caliente</font>\tTucked between rugged desert cliffs and a cottonwood-lined bosque, our hot springs await"
					+ " soakers seeking healing and respite.<br></body></html>";
		} else if (i==3){
			//Changed texts to match new images
			text = "<html><body><font size='5'>#3 New Zealand, Aro Ha</font>\tNestled in the Southern Alps, Aro Ha offers evidence-based wellness intensives that transform "
					+ "your state of wellbeing.<br></body></html>";
		} else if (i==4){
			//Changed texts to match new images
			text = "<html><body><font size='5'>#4 Turkey, Sianji</font>\t A healthy retreat in a luxurious hotel that delivers a first-class wellness programme designed to "
					+ "leave you feeling fully rejuvenated and stress free.</html>";
		} else if (i==5){
			//Changed texts to match new images
			text = "<html><body><font size='5'>#5 Thailand, The Barai</font>\t\tAn award winning destination Spa with 18 remarkable treatment rooms and\"\r\n"
					+ "					+ \" 8 exclusive residential spa suites located on more than 4.5 acres of serene beach<br></body></html>";
		}
		return text;
	}
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				SlideShow ss = new SlideShow();
				ss.setVisible(true);
			}
		});
	}
}